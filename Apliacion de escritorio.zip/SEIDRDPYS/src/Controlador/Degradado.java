/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class Degradado extends JPanel {
    private Color color1;
    private Color color2;

    public void setColors(Color color1, Color color2) {
        this.color1 = color1;
        this.color2 = color2;
    }

    public Color getColor1() {
        return this.color1;
    }

    public Color getColor2() {
        return this.color2;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D G2D = (Graphics2D) g;

        int w = getWidth();
        int h = getHeight();

        GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);

        G2D.setPaint(gp);
        G2D.fillRect(0, 0, w, h);
    }

    public static JPanel aplicarDegradado(JPanel panel, Color color1, Color color2) {
        Degradado mColor = new Degradado();
        mColor.setColors(color1, color2);

        // Copiar propiedades del panel original
        mColor.setSize(panel.getSize());
        mColor.setLocation(panel.getLocation());

        return mColor;
    }

public static JPanel aplicarDegradado(JPanel panel) {
    Degradado mColor = new Degradado();
    mColor.setColors(Color.decode("#3CEEEA"), Color.decode("#FF0033"));

    JPanel panelDegradado = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            panel.paint(g); // Llama al paint del panel original
            mColor.paintComponent(g);
        }
    };

    panelDegradado.setLayout(new BorderLayout());
    panelDegradado.add(panel, BorderLayout.CENTER);
    panelDegradado.setOpaque(false);

    return panelDegradado;
}


}

