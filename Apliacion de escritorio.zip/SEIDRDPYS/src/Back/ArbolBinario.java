package Back;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*@author GiovanNy*/
public class ArbolBinario {
    private Nodo raiz;

    public ArbolBinario() {
        raiz = null;
    }
    public Nodo obtenerRaiz() {
        return raiz;
    }
    public void agregar(int peso, String ContenidoLabel) {
        raiz = agregarRecursivo(raiz, peso, ContenidoLabel);
    }
    private Nodo agregarRecursivo(Nodo actual, int peso, String contenido) {
        if (actual == null) {
            return new Nodo(peso, contenido);
        }
        if (peso < actual.peso) {
            actual.izquierdo = agregarRecursivo(actual.izquierdo, peso, contenido);
        } else if (peso > actual.peso) {
            actual.derecho = agregarRecursivo(actual.derecho, peso, contenido);
        }
        return actual;
    }

    public void cargarDesdeArchivo(String nombreArchivo) {
        try {
            File archivo = new File(nombreArchivo);
            try (Scanner lector = new Scanner(archivo)) {
                while (lector.hasNextLine()) {
                    String linea = lector.nextLine();
                    String[] partes = linea.split(",");
                    int peso = Integer.parseInt(partes[0]);
                    String ContenidoLabel = partes[1];
                    agregar(peso, ContenidoLabel);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se pudo encontrar el archivo.");
            e.printStackTrace();
        }
    }
    
    public void PostOrden(){
        recorrerPostOrdenRecursivo(raiz);
    }
    
    private void recorrerPostOrdenRecursivo(Nodo nodo) {
        if (nodo != null) {
            recorrerPostOrdenRecursivo(nodo.izquierdo);
            recorrerPostOrdenRecursivo(nodo.derecho);
            System.out.println("Peso: " + nodo.peso + ", ContenidoLabel: " + nodo.contenido);
        }
    }
    
}
