package Controlador;
/*@author GiovanNy*/
import Back.ArbolBinario;
import Back.GuardarGenero;
import Back.RegisterLogin;
import Back.Nodo;
import Back.PSInformacion;
import Interfaz.Loggin;
import Interfaz.Principal;
import Interfaz.Register;
import Interfaz.Bienvenida;
import Interfaz.Contenido;
import Interfaz.Cuestionario;
import Interfaz.PeliculasYSeries;
import Interfaz.Salida;
import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ControladorAplicacion implements MouseListener{
    private Principal objVentanaPrincipal;
    private Loggin PanelLoggin = new Loggin();
    private Register PanelRegister = new Register();
    private Bienvenida PanelBienvenida = new Bienvenida();
    private Cuestionario PanelCuestionario = new Cuestionario();
    private PeliculasYSeries PanelPS = new PeliculasYSeries();
    private Salida PanelSalida = new Salida();
    private Contenido PanelContenido = new Contenido();
    
    private Nodo nodoActual;
    //Opción de si es serie o pelicula
    private int opc = 1;
    //Opcion de ver más pelicula o serie
    private int pantallaActual = 1;
    //Genero guardado
    private String Genero;
    private int ID;
    private int Calificacion;
    private String Pelicula;
    private String Path1;
    private String Path2;
    private String Titulo1;
    private String Titulo2;
    private boolean op1;
    private boolean op2; 
    private boolean op3;
    private boolean op4;
    private boolean op5;
    ArbolBinario arbolito = new ArbolBinario();
    public ControladorAplicacion(Principal objVentana){
    this.objVentanaPrincipal = objVentana;
    objVentanaPrincipal.Contenedor.add(PanelLoggin, BorderLayout.CENTER); // Añade Loggin al Contenedor
    objVentanaPrincipal.setVisible(true); // Hace visible la ventana principal
    PanelLoggin.BotonRegistrar.addMouseListener( this);
    PanelLoggin.BotonIniciar.addMouseListener(this);
    PanelRegister.BotonIniciar.addMouseListener(this);
    PanelRegister.BotonRegistrar.addMouseListener(this);
    PanelBienvenida.BotonComenzar.addMouseListener(this);
    PanelCuestionario.BotonSi.addMouseListener(this);
    PanelCuestionario.BotonNo.addMouseListener(this);
    PanelPS.BotonVolverIn.addMouseListener(this);
    PanelPS.BotonSeriesPeliculas.addMouseListener(this);
    PanelPS.BotonMas.addMouseListener(this);
    PanelPS.BotonSalida.addMouseListener(this);
    PanelSalida.BotonVolver.addMouseListener(this);
    PanelSalida.BotonGuardar.addMouseListener(this);
    PanelPS.Poster1.addMouseListener(this);
    PanelPS.Poster2.addMouseListener(this);
    PanelContenido.BotonVolver.addMouseListener(this);
    PanelContenido.Estrella1.addMouseListener(this);
    PanelContenido.Estrella2.addMouseListener(this);
    PanelContenido.Estrella3.addMouseListener(this);
    PanelContenido.Estrella4.addMouseListener(this);
    PanelContenido.Estrella5.addMouseListener(this);
    inicializar();
    
    }
    private void inicializar(){
        //Leer el arbol binario
        String pathArbol = "src/Archivos/Arbol.txt";
        arbolito.cargarDesdeArchivo(pathArbol);
        nodoActual = arbolito.obtenerRaiz();
    }
    
    public ControladorAplicacion(){}
    
    @Override
    public void mouseClicked(MouseEvent e) {
        // Panel Loggin
            System.out.println("Controlador.ControladorAplicacion.mouseClicked()");
        if(e.getSource() == PanelLoggin.BotonRegistrar) MostrarPanel(PanelRegister);
        
        if(e.getSource() == PanelLoggin.BotonIniciar){
            String usuario = PanelLoggin.TextFieldUsuario.getText();
            char[] con = PanelLoggin.PasswordFieldContraseña.getPassword();
            String contraseña = new String(con);
            RegisterLogin RL= new RegisterLogin();
            boolean inicioSesionExitoso = RL.iniciarSesion(usuario, contraseña);
            this.ID = RL.getUserID();
            System.out.println("ID " + ID);
            if (inicioSesionExitoso) {
                MostrarPanel(PanelBienvenida);
            } else JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        // Panel Register
        if(e.getSource() == PanelRegister.BotonIniciar) MostrarPanel(PanelLoggin);

        if(e.getSource() == PanelRegister.BotonRegistrar){
            String nombre = PanelRegister.TextFieldNombre.getText();
            String apellido = PanelRegister.TextFieldApellido.getText();
            String usuario = PanelRegister.TextFieldUsuario.getText();
            String contraseña = PanelRegister.TextFieldContraseña.getText();
            String rContraseña = PanelRegister.TextFielRContraseña.getText();
            String codigoPostal = PanelRegister.TextFieldCodigoP.getText();
            String sexo = (String) PanelRegister.SexoComBox.getSelectedItem();
            if (nombre.isEmpty() || nombre.equals("Ingrese su nombre") ||
                apellido.isEmpty() || apellido.equals("Ingrese su apellido") ||
                usuario.isEmpty() || usuario.equals("Ingrese el nombre de usuario") ||
                contraseña.isEmpty() || contraseña.equals("Ingrese su contraseña") ||
                rContraseña.isEmpty() || rContraseña.equals("Repita su contraseña") ||
                codigoPostal.isEmpty() || codigoPostal.equals("Ingrese el código postal") ||
                sexo.equals("Sin especificar")) {
                    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!contraseña.equals(rContraseña)) {
                JOptionPane.showMessageDialog(null, "Error: Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!isNumeric(codigoPostal)) {
                JOptionPane.showMessageDialog(null, "Error: El código postal debe contener solo números.", "Error", JOptionPane.ERROR_MESSAGE);
            }else if(codigoPostal.length() != 5){
                JOptionPane.showMessageDialog(null, "Error: El código postal debe ser 5 números.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                    RegisterLogin RL = new RegisterLogin();
                    boolean Respuesta = RL.register(usuario, contraseña, nombre, apellido, sexo, codigoPostal);
                    if(!Respuesta) JOptionPane.showMessageDialog(null, "Error: Usuario ya existente.", "Error", JOptionPane.ERROR_MESSAGE);
                    else JOptionPane.showMessageDialog(null, "Los datos se registraron correctamente.", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        //Panel Bienvenida
        if(e.getSource() == PanelBienvenida.BotonComenzar) op(PanelCuestionario);
        //Busqueda
        if(e.getSource() == PanelCuestionario.BotonSi){
            System.out.println("Peso de nodo: " + nodoActual.peso);
            if (nodoActual.izquierdo == null) {
                nodoActual = arbolito.obtenerRaiz();
                op(PanelCuestionario);
            } else nodoActual = nodoActual.izquierdo;
            if(
                nodoActual.peso == 100 ||
                nodoActual.peso == 125 ||
                nodoActual.peso == 225 ||
                nodoActual.peso == 235 ||
                nodoActual.peso == 260 ||
                nodoActual.peso == 275 ||
                nodoActual.peso == 285 ||
                nodoActual.peso == 400 ||
                nodoActual.peso == 435 ||
                nodoActual.peso == 600 ||
                nodoActual.peso == 660 ||
                nodoActual.peso == 705 ||
                nodoActual.peso == 715 ||
                nodoActual.peso == 830 ||
                nodoActual.peso == 860
                ){
                    PantallaP(nodoActual.peso);
                    opc = 2;
            }else op(PanelCuestionario);           
        }
        if(e.getSource() == PanelCuestionario.BotonNo){
            if (nodoActual.derecho == null) {
                nodoActual = arbolito.obtenerRaiz();
                op(PanelCuestionario);
            } else nodoActual = nodoActual.derecho;
            //Pantalla final de resultado de busqueda
            if(
                nodoActual.peso == 100 ||
                nodoActual.peso == 125 ||
                nodoActual.peso == 225 ||
                nodoActual.peso == 235 ||
                nodoActual.peso == 260 ||
                nodoActual.peso == 275 ||
                nodoActual.peso == 285 ||
                nodoActual.peso == 400 ||
                nodoActual.peso == 435 ||
                nodoActual.peso == 600 ||
                nodoActual.peso == 660 ||
                nodoActual.peso == 705 ||
                nodoActual.peso == 715 ||
                nodoActual.peso == 830 ||
                nodoActual.peso == 860
                ){
                    PantallaP(nodoActual.peso);
                    opc = 2;
            }else op(PanelCuestionario);

        }
        //Panel Pelicula y series
        if(e.getSource() == PanelPS.BotonVolverIn){
            nodoActual = arbolito.obtenerRaiz();
            op(PanelCuestionario);          
        }
        if(e.getSource() == PanelPS.BotonMas){
            if(opc == 1){
                PantallaP2(nodoActual.peso);
                opc = 2;
            }else{
                opc = 1;
                PantallaP(nodoActual.peso);
            }
        }
        
        if (e.getSource() == PanelPS.BotonSeriesPeliculas) {
            // Verificar si se está en la pantalla de series
            if (opc == 1) {
                PanelPS.BotonSeriesPeliculas.setText("Ver Peliculas");
                PantallaS(nodoActual.peso);
                opc = 2;
                pantallaActual = 3; // Cambiar a pantalla de películas
            } else {
                PanelPS.BotonSeriesPeliculas.setText("Ver Series");
                PantallaP(nodoActual.peso);
                opc = 1;
                pantallaActual = 1; // Cambiar a pantalla de series
            }
        }
    
        if (e.getSource() == PanelPS.BotonMas) {
            System.out.println("pantalla actual: " + pantallaActual);
            // Verificar si se está en la pantalla de series
            switch (pantallaActual) {
                case 1 -> {
                    System.out.println("Opc:" + opc + " Pantalla P2");
                    PantallaP2(nodoActual.peso);
                    pantallaActual = 2;
                }
                case 2 -> {
                    System.out.println("Opc:" + opc + " Pantalla P1");
                    PantallaP(nodoActual.peso);
                    pantallaActual = 1;
                }
                case 3 -> {
                    System.out.println("Opc: " + opc + " Pantalla S1");
                    PantallaS2(nodoActual.peso);
                    pantallaActual = 4;
                }
                case 4 -> {
                    System.out.println("Opc: " + opc + " Pantalla S2");
                    PantallaS(nodoActual.peso);
                    pantallaActual = 3;
                }    
            }
        }
        
        if(e.getSource() == PanelPS.BotonSalida) MostrarPanel(PanelSalida);
        
        if(e.getSource() == PanelSalida.BotonVolver) PantallaP(nodoActual.peso);
        
        if(e.getSource() ==PanelSalida.BotonGuardar){
            JOptionPane.showMessageDialog(null, "Los datos se registraron correctamente.", "Registro exitoso", 
                    JOptionPane.INFORMATION_MESSAGE);
            GuardarGenero Gg = new GuardarGenero();
            Gg.setGenero(this.Genero); Gg.setID(this.ID);
            Gg.GuardarGenero();
            System.exit(0);
        }
        PSInformacion InformacionPS = new PSInformacion();
        if(e.getSource() == PanelPS.Poster1){
            Pelicula = Titulo1;
            InformacionPS.setearInformacionPelicula(Titulo1);
            Calificar(Titulo1, InformacionPS.getDescripcion(),
                    Path1,InformacionPS.getDirector(),InformacionPS.getAnio()
                    ,InformacionPS.getClasificacion());
            MostrarPanel(PanelContenido);
        }
        if(e.getSource() == PanelPS.Poster2){
            Pelicula = Titulo2;
            InformacionPS.setearInformacionPelicula(Titulo2);
            Calificar(Titulo2, InformacionPS.getDescripcion(),
                    Path2,InformacionPS.getDirector(),InformacionPS.getAnio(),
                    InformacionPS.getClasificacion());
            MostrarPanel(PanelContenido);
        }
        
        if(e.getSource() == PanelContenido.Estrella1){
            if(op1){
                op1= false; op2 = false; op3 = false; op4 = false; op5 = false;
                Calificacion = 0;
            }else{
                op1 = true;
                Calificacion = 1;
            }
        }
        if(e.getSource() == PanelContenido.Estrella2){
            if(op2){
                op1= false; op2 = false; op3 = false; op4 = false; op5 = false;
                Calificacion = 1;
            }else{
                op2 = true;
                Calificacion = 2;
            }
        }
        if(e.getSource() == PanelContenido.Estrella3){
            if(op3){
                op1= false; op2 = false; op3 = false; op4 = false; op5 = false;
                Calificacion = 2;
            }else{
                op3 = true;
                Calificacion = 3;
            }
        }
        if(e.getSource() == PanelContenido.Estrella4){
            if(op4){
                op1= false; op2 = false; op3 = false; op4 = false; op5 = false;
                Calificacion = 3;
            }else{
                op4 = true;
                Calificacion = 4;
            }
        }
        if(e.getSource() == PanelContenido.Estrella5){
            if(op5){
                op1= false; op2 = false; op3 = false; op4 = false; op5 = false;
                Calificacion = 4;
            }else{
                op5 = true;
                Calificacion = 5;
            }
        }
        
        if(e.getSource() == PanelContenido.BotonVolver) {
            System.out.println("Calificacion: " + Calificacion);
            GuardarGenero Gg = new GuardarGenero();
            Gg.setGenero(this.Genero); Gg.setID(this.ID); Gg.setCalifiacion(Calificacion);  Gg.setPelicula(Pelicula);
            Gg.GuardarPeliculaCalificada();
            PantallaP(nodoActual.peso);
        }
    }
    
    private void PantallaS2(Integer actual){
        switch (actual) {
            case 100 -> {
                Genero = "Acción";
                Titulo1 = "Arrow";
                Titulo2 = "Prison Break";
                Path1 = "src/Archivos/PS/Acción/S.Arrow.jpg";
                Path2 = "src/Archivos/PS/Acción/S.Prison Break.jpg";
            }
            case 125 -> {
                Genero = "Wéstern";
                Titulo1 = "Deadwood";
                Titulo2 = "Godless";
                Path1 = "src/Archivos/PS/Wéstern/S.Deadwood.jpg";
                Path2 = "src/Archivos/PS/Wéstern/S.Godless.jpg";
            }
            case 225 ->{
                Genero = "Aventura";
                Titulo1 = "Doctor Who";
                Titulo2 = "Game of Thrones";
                Path1 = "src/Archivos/PS/Aventura/S.Doctor Who.jpg";
                Path2 = "src/Archivos/PS/Aventura/S.Game of Thrones.jpg";
            }
            case 235 ->{
                Genero = "Ciencia Ficción";
                Titulo1 = "Star Trek: The Next Generation";
                Titulo2 = "Stranger Things";
                Path1 = "src/Archivos/PS/Ciencia Ficción/S.Star Trek The Next Generation.jpg";
                Path2 = "src/Archivos/PS/Ciencia Ficción/S.Stranger Things.jpg";
            }
            case 260 ->{
                Genero = "Guerra";
                Titulo1 = "Generation Kill";
                Titulo2 = "M*A*S*H";
                Path1 = "src/Archivos/PS/Guerra/S.Generation Kill.jpg";
                Path2 = "src/Archivos/PS/Guerra/S.MAS H.jpeg";
            }
            case 275 -> {
                Genero = "Biografía";
                Titulo1 = "Narcos";
                Titulo2 = "The Crown";
                Path1 = "src/Archivos/PS/Biografía/S.Narcos.jpg";
                Path2 = "src/Archivos/PS/Biografía/S.The Crown.jpg";
            }
            case 285 ->{
                Genero = "Deportes";
                Titulo1 = "Friday Night Lights";
                Titulo2 = "Ted Lasso";
                Path1 = "src/Archivos/PS/Deportes/S.Friday Night Lights.jpg";
                Path2 = "src/Archivos/PS/Deportes/S.Ted Lasso.jpg";
            }
            case 400 ->{
                Genero = "Comedia";
                Titulo1 = "It's Always Sunny in Philadelphia";
                Titulo2 = "Parks and Recreation";
                Path1 = "src/Archivos/PS/Comedia/S.It's Always Sunny in Philadelphia.jpg";
                Path2 = "src/Archivos/PS/Comedia/S.Parks and Recreation.jpg";
            }
            case 435 ->{
                Genero = "Romance";
                Titulo1 = "Jane the Virgin";
                Titulo2 = "Outlander";
                Path1 = "src/Archivos/PS/Romance/S.Jane the Virgin.jpg";
                Path2 = "src/Archivos/PS/Romance/S.Outlander.jpg";  
            }
            case 600 -> {
                Genero = "Misterio";
                Titulo1 = "The X-Files";
                Titulo2 = "True Detective";
                Path1 = "src/Archivos/PS/Misterio/S.The X-Files.jpg";
                Path2 = "src/Archivos/PS/Misterio/S.True Detective.jpg";
            }
            case 660 -> {
                Genero = "Crimen";
                Titulo1 = "Breaking Bad";
                Titulo2 = "Mindhunter";
                Path1 = "src/Archivos/PS/Crimen/S.Breaking Bad.jpg";
                Path2 = "src/Archivos/PS/Crimen/S.Mindhunter.jpeg";
            }
            case 705 ->{
                Genero = "Terror";
                Titulo1 = "The Haunting of Hill House";
                Titulo2 = "The Walking Dead";
                Path1 = "src/Archivos/PS/Terror/S.The Haunting of Hill House.jpg";
                Path2 = "src/Archivos/PS/Terror/S.The Walking Dead.jpg";
            }
            case 715 ->{
                Genero = "Suspenso";
                Titulo1 = "Dexter";
                Titulo2 = "Mindhunter";
                Path1 = "src/Archivos/PS/Suspense/S.Dexter.jpg";
                Path2 = "src/Archivos/PS/Suspense/S.Mindhunter.jpeg";
            }
            case 830 ->{
                Genero = "Animación";
                Titulo1 = "Gravity Falls";
                Titulo2 = "Rick and Morty";
                Path1 = "src/Archivos/PS/Animación/S.Gravity Falls.jpeg";
                Path2 = "src/Archivos/PS/Animación/S.Rick and Morty.jpeg";
            }
            case 860 ->{
                Genero = "Musical";
                Titulo1 = "High School Musical: The Musical: The Series";
                Titulo2 = "Smash";
                Path1 = "src/Archivos/PS/Musical/S.High School Musical The Musical The Series.jpg";
                Path2 = "src/Archivos/PS/Musical/S.Smash.jpg";
            }
        }
        setPantalla(Genero, Titulo1, Titulo2, Path1, Path2);
    }
    
    private void PantallaS(Integer actual){
        switch (actual) {
            case 100 -> {
                Genero = "Acción";
                Titulo1 = "Breaking Bad";
                Titulo2 = "24";
                Path1 = "src/Archivos/PS/Acción/S,Breaking Bad.jpg";
                Path2 = "src/Archivos/PS/Acción/S.24.jpg";
            }
            case 125 -> {
                Genero = "Wéstern";
                Titulo1 = "Hell on Wheels";
                Titulo2 = "The Son";
                Path1 = "src/Archivos/PS/Wéstern/S.Hell on Wheels.jpg";
                Path2 = "src/Archivos/PS/Wéstern/S.The Son.jpg";
            }
            case 225 ->{
                Genero = "Aventura";
                Titulo1 = "Lost";
                Titulo2 = "The Witcher";
                Path1 = "src/Archivos/PS/Aventura/S.Lost.jpg";
                Path2 = "src/Archivos/PS/Aventura/S.The Witcher.jpeg";
            }
            case 235 ->{
                Genero = "Ciencia Ficción";
                Titulo1 = "Black Mirror";
                Titulo2 = "Doctor Who";
                Path1 = "src/Archivos/PS/Ciencia Ficción/S.Black Mirror.jpg";
                Path2 = "src/Archivos/PS/Ciencia Ficción/S.Doctor Who.jpeg";
            }
            case 260 ->{
                Genero = "Guerra";
                Titulo1 = "Band of Brothers";
                Titulo2 = "Das Boot";
                Path1 = "src/Archivos/PS/Guerra/S.Band of Brothers.jpg";
                Path2 = "src/Archivos/PS/Guerra/S.Das Boot.jpg";
            }
            case 275 -> {
                Genero = "Biografía";
                Titulo1 = "Breaking Bad";
                Titulo2 = "Chernobyl";
                Path1 = "src/Archivos/PS/Biografía/S.Breaking Bad.jpg";
                Path2 = "src/Archivos/PS/Biografía/S.Chernobyl.jpg";
            }
            case 285 ->{
                Genero = "Deportes";
                Titulo1 = "All American";
                Titulo2 = "Coach";
                Path1 = "src/Archivos/PS/Deportes/S.All American.jpg";
                Path2 = "src/Archivos/PS/Deportes/S.Coach.jpg";
            }
            case 400 ->{
                Genero = "Comedia";
                Titulo1 = "Brooklyn Nine-Nine";
                Titulo2 = "Friends";
                Path1 = "src/Archivos/PS/Comedia/S.Brooklyn Nine-Nine.jpg";
                Path2 = "src/Archivos/PS/Comedia/S.Friends.jpg";
            }
            case 435 ->{
                Genero = "Romance";
                Titulo1 = "Friends";
                Titulo2 = "Gilmore Girls";
                Path1 = "src/Archivos/PS/Romance/S.Friends.jpeg";
                Path2 = "src/Archivos/PS/Romance/S.Gilmore Girls.jpg";                  
            }
            case 600 -> {
                Genero = "Misterio";
                Titulo1 = "Broadchurch";
                Titulo2 = "Sherlock";
                Path1 = "src/Archivos/PS/Misterio/S.Broadchurch.jpg";
                Path2 = "src/Archivos/PS/Misterio/S.Sherlock.jpeg";
            }
            case 660 -> {
                Genero = "Crimen";
                Titulo1 = "True Detective";
                Titulo2 = "Sherlock";
                Path1 = "src/Archivos/PS/Crimen/S.True Detective.jpg";
                Path2 = "src/Archivos/PS/Crimen/S.Sherlock.jpg";
            }
            case 705 ->{
                Genero = "Terror";
                Titulo1 = "American Horror Story";
                Titulo2 = "The Haunting of Bly Manor";
                Path1 = "src/Archivos/PS/Terror/S.American Horror Story.jpg";
                Path2 = "src/Archivos/PS/Terror/S.The Haunting of Bly Manor.jpg";
            }
            case 715 ->{
                Genero = "Suspenso";
                Titulo1 = "The Blacklist";
                Titulo2 = "True Detective";
                Path1 = "src/Archivos/PS/Suspense/S.The Blacklist.jpg";
                Path2 = "src/Archivos/PS/Suspense/S.True Detective.jpg";
            }
            case 830 ->{
                Genero = "Animación";
                Titulo1 = "Adventure Time";
                Titulo2 = "Avatar: The Last Airbender";
                Path1 = "src/Archivos/PS/Animación/S.Adventure Time.jpg";
                Path2 = "src/Archivos/PS/Animación/S.Avatar The Last Airbender.jpg";
            }
            case 860 ->{
                Genero = "Musical";
                Titulo1 = "Crazy Ex-Girlfriend";
                Titulo2 = "Glee";
                Path1 = "src/Archivos/PS/Musical/S.Crazy Ex-Girlfriend.jpg";
                Path2 = "src/Archivos/PS/Musical/S.Glee.jpg";
            }
        }
        setPantalla(Genero, Titulo1, Titulo2, Path1, Path2);
    }
    
    private void PantallaP(Integer actual){ 
        switch (actual) {
            case 100 -> {
                Genero = "Acción";
                Titulo1 = "Die Hard";
                Titulo2 = "John Wick";
                Path1 = "src/Archivos/PS/Acción/P.Die Hard.jpg";
                Path2 = "src/Archivos/PS/Acción/P.John Wick.jpg";            
            }
            case 125 -> {
                Genero = "Wéstern";
                Titulo1 = "Django Unchained";
                Titulo2 = "Once Upon a Time in the West";
                Path1 = "src/Archivos/PS/Wéstern/P.Django Unchained.jpg";
                Path2 = "src/Archivos/PS/Wéstern/P.Once Upon a Time in the West.jpg";
            }
            case 225 ->{
                Genero = "Aventura";
                Titulo1 = "Avatar";
                Titulo2 = "Indiana Jones Raiders of the Lost Ark";
                Path1 = "src/Archivos/PS/Aventura/P.Avatar.jpeg";
                Path2 = "src/Archivos/PS/Aventura/P.Indiana Jones Raiders of the Lost ArK.jpg";
            }
            case 235 ->{
                Genero = "Ciencia Ficción";
                Titulo1 = "Inception";
                Titulo2 = "Interstellar";
                Path1 = "src/Archivos/PS/Ciencia Ficción/P.Inception.jpg";
                Path2 = "src/Archivos/PS/Ciencia Ficción/P.Interstellar.jpg";
            }
            case 260 ->{
                Genero = "Guerra";
                Titulo1 = "Full Metal Jacket";
                Titulo2 = "Platoon";
                Path1 = "src/Archivos/PS/Guerra/P.Full Metal Jacket.jpg";
                Path2 = "src/Archivos/PS/Guerra/P.Platoon.jpg";
            }
            case 275 -> {
                Genero = "Biografía";
                Titulo1 = "The King's Speech";
                Titulo2 = "The Pursuit of Happyness";
                Path1 = "src/Archivos/PS/Biografía/P.The King's Speech.jpg";
                Path2 = "src/Archivos/PS/Biografía/P.The Pursuit of Happyness.png";
            }
            case 285 ->{
                Genero = "Deportes";
                Titulo1 = "Remember the Titans";
                Titulo2 = "Rocky";
                Path1 = "src/Archivos/PS/Deportes/P.Remember the Titans.jpg";
                Path2 = "src/Archivos/PS/Deportes/P.Rocky.jpg";
            }
            case 400 ->{
                Genero = "Comedia";
                Titulo1 = "Super Troopers";
                Titulo2 = "Superbad";
                Path1 = "src/Archivos/PS/Comedia/P.Super Troopers.jpg";
                Path2 = "src/Archivos/PS/Comedia/P.Superbad.jpg";
            }
            case 435 ->{
                Genero = "Romance";
                Titulo1 = "Romeo + Juliet";
                Titulo2 = "The Notebook";
                Path1 = "src/Archivos/PS/Romance/P.Romeo + Juliet.jpg";{
                Path2 = "src/Archivos/PS/Romance/P.The Notebook.jpg";                
            }
            }
            case 600 -> {
                Genero = "Misterio";
                Titulo1 = "Se7en";
                Titulo2 = "Shutter Island";
                Path1 = "src/Archivos/PS/Misterio/P.Se7en.jpeg";
                Path2 = "src/Archivos/PS/Misterio/P.Shutter Island.jpg";
            }
            case 660 -> {
                Genero = "Crimen";
                Titulo1 = "The Departed";
                Titulo2 = "The Godfather";
                Path1 = "src/Archivos/PS/Crimen/P.The Departed.jpg";
                Path2 = "src/Archivos/PS/Crimen/P.The Godfather.jpg";
            }
            case 705 ->{
                Genero = "Terror";
                Titulo1 = "Hereditary";
                Titulo2 = "The Exorcist";
                Path1 = "src/Archivos/PS/Terror/P.Hereditary.jpg";
                Path2 = "src/Archivos/PS/Terror/P.The Exorcist.jpg";
            }
            case 715 ->{
                Genero = "Suspenso";
                Titulo1 = "Seven";
                Titulo2 = "Shutter Island";
                Path1 = "src/Archivos/PS/Suspense/P.Seven.jpg";
                Path2 = "src/Archivos/PS/Suspense/P.Shutter Island.jpg";
            }
            case 830 ->{
                Genero = "Animación";
                Titulo1 = "Spirited Away";
                Titulo2 = "The Lion King";
                Path1 = "src/Archivos/PS/Animación/P.Spirited Away.jpg";
                Path2 = "src/Archivos/PS/Animación/P.The Lion King.jpg";
            }
            case 860 ->{
                Genero = "Musical";
                Titulo1 = "The Greatest Showman";
                Titulo2 = "West Side Story";
                Path1 = "src/Archivos/PS/Musical/P.The Greatest Showman.jpg";
                Path2 = "src/Archivos/PS/Musical/P.West Side Story.jpg";
            }
        }
        setPantalla(Genero, Titulo1, Titulo2, Path1, Path2);
    }
    
    private void PantallaP2(Integer actual){
        switch (actual) {
            case 100 -> {
                Genero = "Acción";
                Titulo1 = "Mad Max: Fury Road";
                Titulo2 = "The Dark Knight";
                Path1 = "src/Archivos/PS/Acción/P.Mad_Max_Fury_Road.jpg";
                Path2 = "src/Archivos/PS/Acción/P.The Dark Knight.jpg";
            }
            case 125 -> {
                Genero = "Wéstern";
                Titulo1 = "The Good, the Bad and the Ugly";
                Titulo2 = "The Magnificent Seven";
                Path1 = "src/Archivos/PS/Wéstern/P.The Good, the Bad and the Ugly.jpg";
                Path2 = "src/Archivos/PS/Wéstern/P.The Magnificent Seven.jpg";
            }
            case 225 ->{
                Genero = "Aventura";
                Titulo1 = "Jurassic Park";
                Titulo2 = "Pirates of the Caribbean: The Curse of the Black Pearl";
                Path1 = "src/Archivos/PS/Aventura/P.Jurassic Park.jpg";
                Path2 = "src/Archivos/PS/Aventura/P.Pirates of the Caribbean The Curse of the Black Pearl.png";
            }
            case 235 ->{
                Genero = "Ciencia Ficción";
                Titulo1 = "Avatar";
                Titulo2 = "Blade Runner";
                Path1 = "src/Archivos/PS/Ciencia Ficción/P.Avatar.jpg";
                Path2 = "src/Archivos/PS/Ciencia Ficción/P.Blade Runner.jpeg";
            }
            case 260 ->{
                Genero = "Guerra";
                Titulo1 = "Apocalypse Now";
                Titulo2 = "Dunkirk";
                Path1 = "src/Archivos/PS/Guerra/P.Apocalypse Now.jpg";
                Path2 = "src/Archivos/PS/Guerra/P.Dunkirk.jpg";
            }
            case 275 -> {
                Genero = "Biografía";
                Titulo1 = "A Beautiful Mind";
                Titulo2 = "Schindler's List";
                Path1 = "src/Archivos/PS/Biografía/P.A Beautiful Mind.jpg";
                Path2 = "src/Archivos/PS/Biografía/P.Schindler's List.jpg";
            }
            case 285 ->{
                Genero = "Deportes";
                Titulo1 = "Moneyball";
                Titulo2 = "Raging Bull";
                Path1 = "src/Archivos/PS/Deportes/P.Moneyball.jpeg";
                Path2 = "src/Archivos/PS/Deportes/P.Raging Bull.jpg";
            }
            case 400 ->{
                Genero = "Comedia";
                Titulo1 = "The Legend of Ron Burgundy";
                Titulo2 = "Bridesmaids";
                Path1 = "src/Archivos/PS/Comedia/P.Anchorman The Legend of Ron Burgundy.jpg";
                Path2 = "src/Archivos/PS/Comedia/P.Bridesmaids.jpg";
            }
            case 435 ->{
                Genero = "Romance";
                Titulo1 = "La La Land";
                Titulo2 = "Pride and Prejudice";
                Path1 = "src/Archivos/PS/Romance/P.La La Land.jpeg";
                Path2 = "src/Archivos/PS/Romance/P.Pride and Prejudice.jpg";
            }
            case 600 -> {
                Genero = "Misterio";
                Titulo1 = "Gone Girl";
                Titulo2 = "Prisoners";
                Path1 = "src/Archivos/PS/Misterio/P.Gone Girl.jpg";
                Path2 = "src/Archivos/PS/Misterio/P.Prisoners.jpg";
            }
            case 660 -> {
                Genero = "Crimen";
                Titulo1 = "The Usual Suspects";
                Titulo2 = "Pulp Fiction";
                Path1 = "src/Archivos/PS/Crimen/P.The Usual Suspects.jpg";
                Path2 = "src/Archivos/PS/Crimen/P.Pulp Fiction.jpg";
            }
            case 705 ->{
                Genero = "Terror";
                Titulo1 = "A Nightmare on Elm Street";
                Titulo2 = "Get Out";
                Path1 = "src/Archivos/PS/Terror/P.A Nightmare on Elm Street.jpg";
                Path2 = "src/Archivos/PS/Terror/P.Get Out.jpg";
            }
            case 715 ->{
                Genero = "Suspenso";
                Titulo1 = "Gone Girl";
                Titulo2 = "Prisoners";
                Path1 = "src/Archivos/PS/Suspense/P.Gone Girl.jpg";
                Path2 = "src/Archivos/PS/Suspense/P.Prisoners.jpg";
            }
            case 830 ->{
                Genero = "Animación";
                Titulo1 = "Frozen";
                Titulo2 = "Shrek";
                Path1 = "src/Archivos/PS/Animación/P.Frozen.jpg";
                Path2 = "src/Archivos/PS/Animación/P.Shrek.jpg";
            }
            case 860 ->{
                Genero = "Musical";
                Titulo1 = "Chicago";
                Titulo2 = "Moulin Rouge!";
                Path1 = "src/Archivos/PS/Musical/P.Chicago.jpg";
                Path2 = "src/Archivos/PS/Musical/P.Moulin Rouge!.jpg";
            }
        }
        setPantalla(Genero, Titulo1, Titulo2, Path1, Path2);
    }
    
    private void Calificar(String Titulo, String Descripción, String Imagen,String Director, String anio,String Clasificacion){
            RescalarImagen rs = new RescalarImagen();
            PanelContenido.MostrarPelicula.setSize(238, 320);
            rs.EscalableImagenLabel(PanelContenido.MostrarPelicula, Imagen);
            PanelContenido.ResumenPelicula.setText(StrToHtml(Descripción));
            PanelContenido.Titulo.setText(StrToHtml(Titulo));
            PanelContenido.Clasificacion.setText(StrToHtml("Clasificación: " + Clasificacion));
            PanelContenido.Director.setText(StrToHtml(Director));
            PanelContenido.Anio.setText(StrToHtml("Año: "+anio));
            MostrarPanel(PanelContenido);
    }
    
    private void MostrarPanel(JPanel Panel){
            objVentanaPrincipal.Contenedor.removeAll();
            objVentanaPrincipal.Contenedor.add(Panel, BorderLayout.CENTER);
            objVentanaPrincipal.Contenedor.revalidate();
            objVentanaPrincipal.Contenedor.repaint();
    }
    private void setPantalla(String Genero, String Titulo1, String Titulo2, String Path1, String Path2){
        PanelPS.Poster1.setSize(200,290);
        PanelPS.Poster2.setSize(200,290);
        PanelPS.Genero.setText(StrToHtml(Genero));
        PanelPS.Titulo1.setText(StrToHtml(Titulo1));
        PanelPS.Titulo2.setText(StrToHtml(Titulo2));
        RescalarImagen rs = new RescalarImagen();
        rs.EscalableImagenLabel(PanelPS.Poster1, Path1);
        rs.EscalableImagenLabel(PanelPS.Poster2, Path2);
        objVentanaPrincipal.Contenedor.removeAll();
        objVentanaPrincipal.Contenedor.add(PanelPS, BorderLayout.CENTER);
        objVentanaPrincipal.Contenedor.revalidate();
        objVentanaPrincipal.Contenedor.repaint();
    }
    private void op(JPanel Panel){
        String Label = nodoActual.contenido;
        objVentanaPrincipal.Contenedor.removeAll();
        PanelCuestionario.Text.setText(StrToHtml(Label));
        objVentanaPrincipal.Contenedor.add(Panel, BorderLayout.CENTER);
        objVentanaPrincipal.Contenedor.revalidate();
        objVentanaPrincipal.Contenedor.repaint();
    }
    private boolean isNumeric(String str) { return str.matches("\\d+");}
    private String StrToHtml(String texto){ return "<html><p>" + texto + "</p></html>";}
    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
}