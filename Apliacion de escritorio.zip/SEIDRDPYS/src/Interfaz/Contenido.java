package Interfaz;
import Controlador.RescalarImagen;
import java.awt.Color;
/*@author GiovanNy*/
public class Contenido extends javax.swing.JPanel {

    private boolean op1;
    private boolean op2;
    private boolean op3;
    private boolean op4;
    private boolean op5;
    RescalarImagen rs = new RescalarImagen();
    public Contenido() {
        initComponents();
        Estrella1.setSize(70, 70);
        Estrella2.setSize(70, 70);
        Estrella3.setSize(70, 70);
        Estrella4.setSize(70, 70);
        Estrella5.setSize(70, 70);
        rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella vacia.png");
        rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella vacia.png");
        rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
        rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
        rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JPanel();
        PanelPelicula = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        MostrarPelicula = new javax.swing.JLabel();
        Clasificacion = new javax.swing.JLabel();
        Anio = new javax.swing.JLabel();
        Decoracion = new javax.swing.JPanel();
        ResumenPelicula = new javax.swing.JLabel();
        PanelBotonVolver = new javax.swing.JPanel();
        BotonVolver = new javax.swing.JLabel();
        Director = new javax.swing.JLabel();
        Estrella1 = new javax.swing.JLabel();
        Estrella2 = new javax.swing.JLabel();
        Estrella3 = new javax.swing.JLabel();
        Estrella4 = new javax.swing.JLabel();
        Estrella5 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        Back.setBackground(new java.awt.Color(255, 255, 255));
        Back.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelPelicula.setBackground(new java.awt.Color(255, 0, 51));

        Titulo.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("TITULO");
        Titulo.setMaximumSize(new java.awt.Dimension(40, 18));
        Titulo.setMinimumSize(new java.awt.Dimension(40, 19));

        javax.swing.GroupLayout PanelPeliculaLayout = new javax.swing.GroupLayout(PanelPelicula);
        PanelPelicula.setLayout(PanelPeliculaLayout);
        PanelPeliculaLayout.setHorizontalGroup(
            PanelPeliculaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Titulo, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
            .addGroup(PanelPeliculaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MostrarPelicula, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        PanelPeliculaLayout.setVerticalGroup(
            PanelPeliculaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelPeliculaLayout.createSequentialGroup()
                .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MostrarPelicula, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
                .addContainerGap())
        );

        Back.add(PanelPelicula, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 250, 360));

        Clasificacion.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        Clasificacion.setForeground(new java.awt.Color(0, 0, 0));
        Clasificacion.setText("Clasificación:");
        Back.add(Clasificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 390, 240, 30));

        Anio.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        Anio.setForeground(new java.awt.Color(0, 0, 0));
        Anio.setText("Año de Lanzamiento");
        Back.add(Anio, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 360, 240, -1));

        Decoracion.setBackground(new java.awt.Color(47, 58, 65));

        ResumenPelicula.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        ResumenPelicula.setForeground(new java.awt.Color(255, 255, 255));
        ResumenPelicula.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ResumenPelicula.setText("Resumen");
        ResumenPelicula.setMaximumSize(new java.awt.Dimension(40, 18));
        ResumenPelicula.setMinimumSize(new java.awt.Dimension(40, 19));

        javax.swing.GroupLayout DecoracionLayout = new javax.swing.GroupLayout(Decoracion);
        Decoracion.setLayout(DecoracionLayout);
        DecoracionLayout.setHorizontalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DecoracionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ResumenPelicula, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
                .addContainerGap())
        );
        DecoracionLayout.setVerticalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DecoracionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ResumenPelicula, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
        );

        Back.add(Decoracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 600, 270));

        PanelBotonVolver.setBackground(new java.awt.Color(255, 0, 51));

        BotonVolver.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        BotonVolver.setForeground(new java.awt.Color(255, 255, 255));
        BotonVolver.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonVolver.setText("Volver");
        BotonVolver.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonVolverMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonVolverMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonVolverMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PanelBotonVolverLayout = new javax.swing.GroupLayout(PanelBotonVolver);
        PanelBotonVolver.setLayout(PanelBotonVolverLayout);
        PanelBotonVolverLayout.setHorizontalGroup(
            PanelBotonVolverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonVolver, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
        );
        PanelBotonVolverLayout.setVerticalGroup(
            PanelBotonVolverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonVolver, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Back.add(PanelBotonVolver, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 40));

        Director.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        Director.setForeground(new java.awt.Color(0, 0, 0));
        Director.setText("Autor / Director");
        Back.add(Director, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 290, 240, 70));

        Estrella1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Estrella1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Estrella1MouseClicked(evt);
            }
        });
        Back.add(Estrella1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 290, 70, 70));

        Estrella2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Estrella2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Estrella2MouseClicked(evt);
            }
        });
        Back.add(Estrella2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 290, 70, 70));

        Estrella3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Estrella3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Estrella3MouseClicked(evt);
            }
        });
        Back.add(Estrella3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 290, 70, 70));

        Estrella4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Estrella4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Estrella4MouseClicked(evt);
            }
        });
        Back.add(Estrella4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 290, 70, 70));

        Estrella5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Estrella5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Estrella5MouseClicked(evt);
            }
        });
        Back.add(Estrella5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 290, 70, 70));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Back, javax.swing.GroupLayout.PREFERRED_SIZE, 900, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Back, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BotonVolverMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonVolverMouseEntered
        // TODO add your handling code here:
        PanelBotonVolver.setBackground(new Color(255, 51, 58));
    }//GEN-LAST:event_BotonVolverMouseEntered

    private void BotonVolverMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonVolverMouseExited
        // TODO add your handling code here:
        PanelBotonVolver.setBackground(new Color(255, 0, 51));
    }//GEN-LAST:event_BotonVolverMouseExited

    private void Estrella1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Estrella1MouseClicked
        // TODO add your handling code here:
        if(op1){
            op1 = false; op2 = false; op3 = false; op4 = false; op5 = false;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }
        else{  
            op1 = true;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }
    }//GEN-LAST:event_Estrella1MouseClicked

    private void Estrella2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Estrella2MouseClicked
        // TODO add your handling code here:
        if(op2){
            op1 = false; op2 = false; op3 = false; op4 = false; op5 = false;
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }else{
            op2 = true;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }
    }//GEN-LAST:event_Estrella2MouseClicked

    private void Estrella3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Estrella3MouseClicked
        // TODO add your handling code here:
        if(op3){
            op1 = false; op2 = false; op3 = false; op4 = false; op5 = false;
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }else{
            op3 = true;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }
    }//GEN-LAST:event_Estrella3MouseClicked

    private void Estrella4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Estrella4MouseClicked
        // TODO add your handling code here:
        if(op4){
            op1 = false; op2 = false; op3 = false; op4 = false; op5 = false;;
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }else{
            op4 = true;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }
    }//GEN-LAST:event_Estrella4MouseClicked

    private void Estrella5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Estrella5MouseClicked
        // TODO add your handling code here:
        if(op5){
            op1 = false; op2 = false; op3 = false; op4 = false; op5 = false;;
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
        }else{
            op5 = true;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella Llena.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella Llena.png");
        }
    }//GEN-LAST:event_Estrella5MouseClicked

    private void BotonVolverMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonVolverMouseClicked
        // TODO add your handling code here:
            op5 = false;
            rs.EscalableImagenLabel(Estrella1, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella2, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella3, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella4, "src/Archivos/Estrella vacia.png");
            rs.EscalableImagenLabel(Estrella5, "src/Archivos/Estrella vacia.png");
    }//GEN-LAST:event_BotonVolverMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel Anio;
    private javax.swing.JPanel Back;
    public javax.swing.JLabel BotonVolver;
    public javax.swing.JLabel Clasificacion;
    private javax.swing.JPanel Decoracion;
    public javax.swing.JLabel Director;
    public javax.swing.JLabel Estrella1;
    public javax.swing.JLabel Estrella2;
    public javax.swing.JLabel Estrella3;
    public javax.swing.JLabel Estrella4;
    public javax.swing.JLabel Estrella5;
    public javax.swing.JLabel MostrarPelicula;
    public javax.swing.JPanel PanelBotonVolver;
    private javax.swing.JPanel PanelPelicula;
    public javax.swing.JLabel ResumenPelicula;
    public javax.swing.JLabel Titulo;
    // End of variables declaration//GEN-END:variables
}
