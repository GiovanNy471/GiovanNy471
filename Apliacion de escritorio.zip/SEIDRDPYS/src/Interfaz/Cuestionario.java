package Interfaz;
import java.awt.Color;
/*@author GiovanNy*/
public class Cuestionario extends javax.swing.JPanel {
    public Cuestionario() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JPanel();
        Decoracion = new javax.swing.JPanel();
        PanelSi = new javax.swing.JPanel();
        BotonSi = new javax.swing.JLabel();
        Text = new javax.swing.JLabel();
        PanelNo = new javax.swing.JPanel();
        BotonNo = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(910, 470));

        Back.setBackground(new java.awt.Color(255, 255, 255));
        Back.setPreferredSize(new java.awt.Dimension(910, 470));
        Back.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Decoracion.setBackground(new java.awt.Color(255, 0, 51));

        javax.swing.GroupLayout DecoracionLayout = new javax.swing.GroupLayout(Decoracion);
        Decoracion.setLayout(DecoracionLayout);
        DecoracionLayout.setHorizontalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 910, Short.MAX_VALUE)
        );
        DecoracionLayout.setVerticalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        Back.add(Decoracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, 910, 40));

        PanelSi.setBackground(new java.awt.Color(255, 0, 51));

        BotonSi.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        BotonSi.setForeground(new java.awt.Color(255, 255, 255));
        BotonSi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonSi.setText("Si");
        BotonSi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonSi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonSiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonSiMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PanelSiLayout = new javax.swing.GroupLayout(PanelSi);
        PanelSi.setLayout(PanelSiLayout);
        PanelSiLayout.setHorizontalGroup(
            PanelSiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonSi, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
        );
        PanelSiLayout.setVerticalGroup(
            PanelSiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonSi, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        Back.add(PanelSi, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 150, 50));

        Text.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        Text.setForeground(new java.awt.Color(0, 0, 0));
        Text.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Text.setText("jLabel1");
        Back.add(Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 820, 80));

        PanelNo.setBackground(new java.awt.Color(255, 0, 51));

        BotonNo.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        BotonNo.setForeground(new java.awt.Color(255, 255, 255));
        BotonNo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonNo.setText("No");
        BotonNo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonNoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonNoMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PanelNoLayout = new javax.swing.GroupLayout(PanelNo);
        PanelNo.setLayout(PanelNoLayout);
        PanelNoLayout.setHorizontalGroup(
            PanelNoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonNo, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
        );
        PanelNoLayout.setVerticalGroup(
            PanelNoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonNo, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        Back.add(PanelNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 340, 150, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Back, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Back, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BotonSiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonSiMouseEntered
        // TODO add your handling code here:
        BotonSi.setBackground(new Color(255, 51, 58));
    }//GEN-LAST:event_BotonSiMouseEntered

    private void BotonSiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonSiMouseExited
        // TODO add your handling code here:
        BotonSi.setBackground(new Color(255, 0, 51));
    }//GEN-LAST:event_BotonSiMouseExited

    private void BotonNoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonNoMouseEntered
        // TODO add your handling code here:
        BotonNo.setBackground(new Color(255, 51, 58));
    }//GEN-LAST:event_BotonNoMouseEntered

    private void BotonNoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonNoMouseExited
        // TODO add your handling code here:
        BotonNo.setBackground(new Color(255, 0, 51));
    }//GEN-LAST:event_BotonNoMouseExited

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Back;
    public javax.swing.JLabel BotonNo;
    public javax.swing.JLabel BotonSi;
    private javax.swing.JPanel Decoracion;
    private javax.swing.JPanel PanelNo;
    private javax.swing.JPanel PanelSi;
    public javax.swing.JLabel Text;
    // End of variables declaration//GEN-END:variables

}
