
package Back;
/**
 * @author giova
 */
public class ADRC {
    private void cargarBase(){
        
    }
}
