package Back;
/*@author giova*/
public class Nodo {
    public int peso;
    public String contenido;
    public Nodo izquierdo;
    public Nodo derecho;

    public Nodo(int peso, String contenido) {
        this.peso = peso;
        this.contenido = contenido;
        this.izquierdo = null;
        this.derecho = null;
    }
}