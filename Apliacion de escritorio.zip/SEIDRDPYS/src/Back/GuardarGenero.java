package Back;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*@author GiovanNy*/
public class GuardarGenero {
    private int ID;
    private String Genero;
    private String Pelicula;
    private int Califiacion;
    
    private void guardarPelicula() {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("src/Archivos/PeliculasCalificadas.txt", true)))) {
            out.println(this.ID + "," + this.Genero + "," + this.Pelicula + "," + this.Califiacion);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }
    private void guardarGenero() {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("src/Archivos/GenerosGuardados.txt", true)))) {
            out.println(this.ID + "," + this.Genero);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }
    public void GuardarGenero(){guardarGenero();}
    public void GuardarPeliculaCalificada(){guardarPelicula();}
    public void setID(int ID){this.ID = ID;}
    public void setGenero(String Genero){this.Genero = Genero;}
    public void setPelicula(String Pelicula){this.Pelicula = Pelicula;}
    public void setCalifiacion(int Calificacion){this.Califiacion = Calificacion;}
}