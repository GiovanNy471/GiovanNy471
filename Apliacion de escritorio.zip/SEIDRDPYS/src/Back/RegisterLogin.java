package Back;

import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class RegisterLogin {
    private HashMap<String, String> usuarios = new HashMap<>();
    private int idCounter = 1; // Contador para generar IDs únicos
    private int userID; // Variable para almacenar el ID del usuario actual

    public RegisterLogin() {
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        try {
            File archivo = new File("src/Archivos/usuarios.txt");
            try (Scanner sc = new Scanner(archivo)) {
                while (sc.hasNextLine()) {
                    String[] datos = sc.nextLine().split(",");
                    usuarios.put(datos[0], datos[1]);
                    idCounter++; // Incrementar contador al cargar un usuario existente
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo no fue encontrado: " + e.getMessage());
        }
    }

    public boolean register(String usuario, String contraseña, String nombre, String apellido, String sexo, String codigoPostal) {
        // Verificar si el usuario ya existe
        boolean respuesta = false;
        if (usuarios.containsKey(usuario)) {
            System.out.println("El usuario ya existe.");
        } else {
            // Si el usuario no existe, añadirlo al HashMap y guardar en el archivo
            usuarios.put(usuario, contraseña + "," + nombre + "," + apellido + "," + sexo + "," + codigoPostal);
            guardarUsuario(usuario, contraseña, nombre, apellido, sexo, codigoPostal);
            System.out.println("Usuario registrado con éxito. ID: " + idCounter);
            userID = idCounter; // Establecer el ID del usuario actual
            idCounter++; // Incrementar contador al registrar un nuevo usuario
            respuesta = true;
        }
        return respuesta;
    }

    private void guardarUsuario(String usuario, String contraseña, String nombre, String apellido, String sexo, String codigoPostal) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("src/Archivos/usuarios.txt", true)))) {
            out.println(usuario + "," + contraseña + "," + nombre + "," + apellido + "," + sexo + "," + codigoPostal + "," + idCounter);
        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }

    public boolean iniciarSesion(String usuario, String contraseña) {
        if (usuarios.containsKey(usuario) && usuarios.get(usuario).equals(contraseña)) {
            System.out.println("Inicio de sesión exitoso.");
            setUserID(usuario);
            return true;
        } else {
            System.out.println("Usuario o contraseña incorrectos.");
            return false;
        }
    }

    // Método get para obtener el ID del usuario actual
    public int getUserID() {
        return userID;
    }

    // Método set para establecer el ID del usuario actual
    private void setUserID(String Usuario) {
        String archivo = "src/Archivos/usuarios.txt"; // Ruta al archivo de texto
        try {
            BufferedReader br = new BufferedReader(new FileReader(archivo));
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(","); // Separar la línea por comas
                for (String dato : datos) {
                    if (dato.equals(Usuario)) {
                        String ultimoDato = datos[datos.length - 1];
                        this.userID = Integer.parseInt(ultimoDato);
                    }
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    
    }
}