package Back;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/*@author GiovanNy*/
public class PSInformacion {
    private String Genero;
    private String Tipo;
    private String Titulo;
    private String Director;
    private String Año;
    private String Clasificacion;
    private String Descripcion;
    
    public void setearInformacionPelicula(String PeliculaNombre) {
        String filePath = "src/Archivos/DescripcionPeliculas.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                    System.out.println("Antes de comparar" + PeliculaNombre);
                if(parts[2].equals(PeliculaNombre)){
                    System.out.println("Pelicula" + PeliculaNombre);
                    setGenero(parts[0]);
                    setTipo(parts[1]);
                    setTitulo(parts[2]);
                    setDirector(parts[3]);
                    setAnio(parts[4]);
                    setClasificacion(parts[5]);
                    setDescripcion(parts[6]);
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println("Archivo no encontrado");
        }
    }

    private void setGenero(String Genero) {
        this.Genero = Genero;
    }
    private void setTipo(String Tipo){
        this.Tipo = Tipo;
    }
    private void setTitulo(String Titulo){
        this.Titulo = Titulo;
    }
    private void setDirector(String Director){
        this.Director = Director;
    }
    private void setAnio(String Anio){
        this.Año = Anio;
    }
    private void setClasificacion(String Clasificacion){
        this.Clasificacion = Clasificacion;
    }
    private void setDescripcion(String Descripcion){
        this.Descripcion = Descripcion;
    }
    public String getGenero(){
        return Genero;
    }
    public String getTipo(){
        return Tipo;
    }
    public String getTitulo(){
        return Titulo;
    }
    public String getDirector(){
        return Director;
    }
    public String getAnio(){
        return Año;
    }
    public String getClasificacion(){
        return Clasificacion;
    }
    public String getDescripcion(){
        return Descripcion;
    }
}
