/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Interfaz;

import Controlador.RescalarImagen;
import java.awt.Color;
import javax.swing.JOptionPane;
/*@author giova */
public class Register extends javax.swing.JPanel {
    private String[] Datos = new String [6];
    private boolean listo;
    public Register() {
        initComponents();
        LabelLogo.setSize(125, 127);
        RescalarImagen rs = new RescalarImagen();
        rs.EscalableImagenLabel(LabelLogo, "src/Interfaz/Imagenes/LogoIn.png");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JPanel();
        Decoracion = new javax.swing.JPanel();
        LabelLogo = new javax.swing.JLabel();
        Contenido = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Text1 = new javax.swing.JLabel();
        TextN = new javax.swing.JLabel();
        TextFieldNombre = new javax.swing.JTextField();
        TextA = new javax.swing.JLabel();
        TextFieldApellido = new javax.swing.JTextField();
        TextNU = new javax.swing.JLabel();
        TextFieldUsuario = new javax.swing.JTextField();
        TextC = new javax.swing.JLabel();
        TextFieldContraseña = new javax.swing.JTextField();
        TextRC = new javax.swing.JLabel();
        TextFielRContraseña = new javax.swing.JTextField();
        Contenido2 = new javax.swing.JPanel();
        PBotonR = new javax.swing.JPanel();
        BotonRegistrar = new javax.swing.JLabel();
        PBotonIn = new javax.swing.JPanel();
        BotonIniciar = new javax.swing.JLabel();
        TextS = new javax.swing.JLabel();
        SexoComBox = new javax.swing.JComboBox<>();
        TextCBox = new javax.swing.JLabel();
        TextFieldCodigoP = new javax.swing.JTextField();
        Separador1 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();

        setMinimumSize(new java.awt.Dimension(840, 470));
        setPreferredSize(new java.awt.Dimension(890, 470));
        setLayout(new java.awt.BorderLayout());

        Back.setBackground(new java.awt.Color(255, 255, 255));
        Back.setPreferredSize(new java.awt.Dimension(870, 300));
        Back.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Decoracion.setBackground(new java.awt.Color(51, 204, 255));
        Decoracion.setPreferredSize(new java.awt.Dimension(250, 470));

        javax.swing.GroupLayout DecoracionLayout = new javax.swing.GroupLayout(Decoracion);
        Decoracion.setLayout(DecoracionLayout);
        DecoracionLayout.setHorizontalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DecoracionLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(LabelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(53, Short.MAX_VALUE))
        );
        DecoracionLayout.setVerticalGroup(
            DecoracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DecoracionLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(LabelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(316, Short.MAX_VALUE))
        );

        Back.add(Decoracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 470));

        Contenido.setBackground(new java.awt.Color(255, 255, 255));
        Contenido.setPreferredSize(new java.awt.Dimension(640, 470));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        Text1.setFont(new java.awt.Font("Roboto Black", 0, 36)); // NOI18N
        Text1.setText("Registrarse");

        TextN.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        TextN.setText("Nombre");
        TextN.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        TextFieldNombre.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFieldNombre.setForeground(new java.awt.Color(153, 153, 153));
        TextFieldNombre.setText("Ingrese su nombre");
        TextFieldNombre.setBorder(null);
        TextFieldNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFieldNombreMousePressed(evt);
            }
        });
        TextFieldNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldNombreActionPerformed(evt);
            }
        });

        TextA.setFont(new java.awt.Font("Roboto Medium", 0, 24)); // NOI18N
        TextA.setText("Apellido");
        TextA.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        TextFieldApellido.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFieldApellido.setForeground(new java.awt.Color(153, 153, 153));
        TextFieldApellido.setText("Ingrese su apellido");
        TextFieldApellido.setBorder(null);
        TextFieldApellido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFieldApellidoMousePressed(evt);
            }
        });
        TextFieldApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldApellidoActionPerformed(evt);
            }
        });

        TextNU.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TextNU.setText("Nombre de usuario");
        TextNU.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        TextFieldUsuario.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFieldUsuario.setForeground(new java.awt.Color(153, 153, 153));
        TextFieldUsuario.setText("Ingrese el nombre de usuario");
        TextFieldUsuario.setBorder(null);
        TextFieldUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFieldUsuarioMousePressed(evt);
            }
        });
        TextFieldUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldUsuarioActionPerformed(evt);
            }
        });

        TextC.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TextC.setText("Contraseña");

        TextFieldContraseña.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFieldContraseña.setForeground(new java.awt.Color(153, 153, 153));
        TextFieldContraseña.setText("Ingrese su contraseña");
        TextFieldContraseña.setBorder(null);
        TextFieldContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFieldContraseñaMousePressed(evt);
            }
        });
        TextFieldContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldContraseñaActionPerformed(evt);
            }
        });

        TextRC.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TextRC.setText("Repita la contraseña");
        TextRC.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        TextFielRContraseña.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFielRContraseña.setForeground(new java.awt.Color(153, 153, 153));
        TextFielRContraseña.setText("Repita su contraseña");
        TextFielRContraseña.setBorder(null);
        TextFielRContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFielRContraseñaMousePressed(evt);
            }
        });
        TextFielRContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFielRContraseñaActionPerformed(evt);
            }
        });

        Contenido2.setBackground(new java.awt.Color(255, 255, 255));

        PBotonR.setBackground(new java.awt.Color(51, 204, 255));

        BotonRegistrar.setBackground(new java.awt.Color(255, 255, 255));
        BotonRegistrar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        BotonRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        BotonRegistrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonRegistrar.setText("Registrarse");
        BotonRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PBotonRLayout = new javax.swing.GroupLayout(PBotonR);
        PBotonR.setLayout(PBotonRLayout);
        PBotonRLayout.setHorizontalGroup(
            PBotonRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonRegistrar, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
        );
        PBotonRLayout.setVerticalGroup(
            PBotonRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonRegistrar, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        PBotonIn.setBackground(new java.awt.Color(51, 204, 255));

        BotonIniciar.setBackground(new java.awt.Color(255, 255, 255));
        BotonIniciar.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        BotonIniciar.setForeground(new java.awt.Color(255, 255, 255));
        BotonIniciar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonIniciar.setText("Iniciar Sesión");
        BotonIniciar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BotonIniciar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonIniciarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonIniciarMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PBotonInLayout = new javax.swing.GroupLayout(PBotonIn);
        PBotonIn.setLayout(PBotonInLayout);
        PBotonInLayout.setHorizontalGroup(
            PBotonInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonIniciar, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
        );
        PBotonInLayout.setVerticalGroup(
            PBotonInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BotonIniciar, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        TextS.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TextS.setText("Sexo:");
        TextS.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        SexoComBox.setBackground(new java.awt.Color(255, 255, 255));
        SexoComBox.setFont(new java.awt.Font("Roboto Medium", 0, 12)); // NOI18N
        SexoComBox.setForeground(new java.awt.Color(0, 0, 0));
        SexoComBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sin especificar", "H", "M" }));

        TextCBox.setFont(new java.awt.Font("Roboto Medium", 0, 18)); // NOI18N
        TextCBox.setText("Código postal");
        TextCBox.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        TextFieldCodigoP.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        TextFieldCodigoP.setForeground(new java.awt.Color(153, 153, 153));
        TextFieldCodigoP.setText("Ingrese el código postal");
        TextFieldCodigoP.setBorder(null);
        TextFieldCodigoP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                TextFieldCodigoPMousePressed(evt);
            }
        });
        TextFieldCodigoP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldCodigoPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Contenido2Layout = new javax.swing.GroupLayout(Contenido2);
        Contenido2.setLayout(Contenido2Layout);
        Contenido2Layout.setHorizontalGroup(
            Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Contenido2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Contenido2Layout.createSequentialGroup()
                        .addComponent(Separador1)
                        .addContainerGap())
                    .addGroup(Contenido2Layout.createSequentialGroup()
                        .addComponent(PBotonR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PBotonIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Contenido2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SexoComBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TextS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 240, Short.MAX_VALUE)
                .addGroup(Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator4)
                    .addComponent(TextFieldCodigoP, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
                    .addComponent(TextCBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        Contenido2Layout.setVerticalGroup(
            Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Contenido2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Separador1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Contenido2Layout.createSequentialGroup()
                        .addComponent(TextS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SexoComBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Contenido2Layout.createSequentialGroup()
                        .addComponent(TextCBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldCodigoP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(Contenido2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PBotonR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PBotonIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Text1)
                .addGap(206, 206, 206))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Contenido2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TextFieldContraseña)
                            .addComponent(TextC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TextFielRContraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(TextRC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextFieldUsuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextNU, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jSeparator2)
                            .addComponent(TextFieldNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextN, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TextFieldApellido, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                            .addComponent(TextA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator3))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Text1)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(TextN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(TextA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(TextNU)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextC)
                    .addComponent(TextRC))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextFieldContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextFielRContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Contenido2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout ContenidoLayout = new javax.swing.GroupLayout(Contenido);
        Contenido.setLayout(ContenidoLayout);
        ContenidoLayout.setHorizontalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        ContenidoLayout.setVerticalGroup(
            ContenidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContenidoLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Back.add(Contenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 610, 470));

        add(Back, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void TextFieldNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldNombreActionPerformed

    private void TextFieldApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldApellidoActionPerformed

    private void TextFieldUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldUsuarioActionPerformed

    private void TextFieldContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldContraseñaActionPerformed

    public void setListo(boolean listo){
        this.listo = listo;
    }
    public boolean getListo(){
        return this.listo;
    }
    private void TextFieldNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFieldNombreMousePressed
        if (TextFieldNombre.getText().equals("Ingrese su nombre")) {
                TextFieldNombre.setText("");
                TextFieldNombre.setForeground(Color.BLACK);
        }
        if(TextFieldApellido.getText().isEmpty()){
             TextFieldApellido.setText("Ingrese su apellido");
             TextFieldApellido.setForeground(Color.gray);
        }
        if(TextFieldUsuario.getText().isEmpty()){
            TextFieldUsuario.setText("Ingrese el nombre de usuario");
            TextFieldUsuario.setForeground(Color.gray);
        }
        if(TextFieldContraseña.getText().isEmpty()){
            TextFieldContraseña.setText("Ingrese su contraseña");
            TextFieldContraseña.setForeground(Color.gray);
        }
        if(TextFielRContraseña.getText().isEmpty()){
            TextFielRContraseña.setText("Repita su contraseña");
            TextFielRContraseña.setForeground(Color.gray);
        }
        if(TextFieldCodigoP.getText().isEmpty()){
            TextFieldCodigoP.setText("Ingrese el código postal");
            TextFieldCodigoP.setForeground(Color.gray);
        }        
        // TODO add your handling code here:
        
    }//GEN-LAST:event_TextFieldNombreMousePressed

    private void TextFieldApellidoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFieldApellidoMousePressed
        if (TextFieldApellido.getText().equals("Ingrese su apellido")) {
            TextFieldApellido.setText("");
            TextFieldApellido.setForeground(Color.BLACK);
        }
        if(TextFieldNombre.getText().isEmpty()){
            TextFieldNombre.setText("Ingrese su nombre");
            TextFieldNombre.setForeground(Color.gray);
        }
        if(TextFieldUsuario.getText().isEmpty()){
            TextFieldUsuario.setText("Ingrese el nombre de usuario");
            TextFieldUsuario.setForeground(Color.gray);
        }
        if(TextFieldContraseña.getText().isEmpty()){
            TextFieldContraseña.setText("Ingrese su contraseña");
            TextFieldContraseña.setForeground(Color.gray);
        }
        if(TextFielRContraseña.getText().isEmpty()){
            TextFielRContraseña.setText("Repita su contraseña");
            TextFielRContraseña.setForeground(Color.gray);
        }
        if(TextFieldCodigoP.getText().isEmpty()){
            TextFieldCodigoP.setText("Ingrese el código postal");
            TextFieldCodigoP.setForeground(Color.gray);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldApellidoMousePressed

    private void TextFieldUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFieldUsuarioMousePressed
        if (TextFieldUsuario.getText().equals("Ingrese el nombre de usuario")) {
            TextFieldUsuario.setText("");
            TextFieldUsuario.setForeground(Color.BLACK);
        }
        if(TextFieldNombre.getText().isEmpty()){
            TextFieldNombre.setText("Ingrese su nombre");
            TextFieldNombre.setForeground(Color.gray);
        }
        if(TextFieldApellido.getText().isEmpty()){
            TextFieldApellido.setText("Ingrese su apellido");
            TextFieldApellido.setForeground(Color.gray);
        }
        if(TextFieldContraseña.getText().isEmpty()){
            TextFieldContraseña.setText("Ingrese su contraseña");
            TextFieldContraseña.setForeground(Color.gray);
        }
        if(TextFielRContraseña.getText().isEmpty()){
            TextFielRContraseña.setText("Repita su contraseña");
            TextFielRContraseña.setForeground(Color.gray);
        }
        if(TextFieldCodigoP.getText().isEmpty()){
            TextFieldCodigoP.setText("Ingrese el código postal");
            TextFieldCodigoP.setForeground(Color.gray);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldUsuarioMousePressed

    private void TextFieldContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFieldContraseñaMousePressed
        // TODO add your handling code here:
        if (TextFieldContraseña.getText().equals("Ingrese su contraseña")) {
            TextFieldContraseña.setText("");
            TextFieldContraseña.setForeground(Color.BLACK);
        }
        if(TextFieldNombre.getText().isEmpty()){
            TextFieldNombre.setText("Ingrese su nombre");
            TextFieldNombre.setForeground(Color.gray);
        }
        if(TextFieldApellido.getText().isEmpty()){
            TextFieldApellido.setText("Ingrese su apellido");
            TextFieldApellido.setForeground(Color.gray);
        }
        if(TextFieldUsuario.getText().isEmpty()){
            TextFieldUsuario.setText("Ingrese el nombre de usuario");
            TextFieldUsuario.setForeground(Color.gray);
        }
        if(TextFielRContraseña.getText().isEmpty()){
            TextFielRContraseña.setText("Repita su contraseña");
            TextFielRContraseña.setForeground(Color.gray);
        }
        if(TextFieldCodigoP.getText().isEmpty()){
            TextFieldCodigoP.setText("Ingrese el código postal");
            TextFieldCodigoP.setForeground(Color.gray);
        }
    }//GEN-LAST:event_TextFieldContraseñaMousePressed

    private void TextFielRContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFielRContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFielRContraseñaActionPerformed

    private void TextFielRContraseñaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFielRContraseñaMousePressed
        // TODO add your handling code here:
        if (TextFielRContraseña.getText().equals("Repita su contraseña")) {
            TextFielRContraseña.setText("");
            TextFielRContraseña.setForeground(Color.BLACK);
        }
        if(TextFieldNombre.getText().isEmpty()){
            TextFieldNombre.setText("Ingrese su nombre");
            TextFieldNombre.setForeground(Color.gray);
        }
        if(TextFieldApellido.getText().isEmpty()){
            TextFieldApellido.setText("Ingrese su apellido");
            TextFieldApellido.setForeground(Color.gray);
        }
        if(TextFieldUsuario.getText().isEmpty()){
            TextFieldUsuario.setText("Ingrese el nombre de usuario");
            TextFieldUsuario.setForeground(Color.gray);
        }
        if(TextFieldContraseña.getText().isEmpty()){
            TextFieldContraseña.setText("Ingrese su contraseña");
            TextFieldContraseña.setForeground(Color.gray);
        }
        if(TextFieldCodigoP.getText().isEmpty()){
            TextFieldCodigoP.setText("Ingrese el código postal");
            TextFieldCodigoP.setForeground(Color.gray);
        }
    }//GEN-LAST:event_TextFielRContraseñaMousePressed

    private void TextFieldCodigoPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldCodigoPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldCodigoPActionPerformed

    private void TextFieldCodigoPMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TextFieldCodigoPMousePressed
        // TODO add your handling code here:
        if (TextFieldCodigoP.getText().equals("Ingrese el código postal")) {
            TextFieldCodigoP.setText("");
            TextFieldCodigoP.setForeground(Color.BLACK);
        }
        if(TextFieldNombre.getText().isEmpty()){
            TextFieldNombre.setText("Ingrese su nombre");
            TextFieldNombre.setForeground(Color.gray);
        }
        if(TextFieldApellido.getText().isEmpty()){
            TextFieldApellido.setText("Ingrese su apellido");
            TextFieldApellido.setForeground(Color.gray);
        }
        if(TextFieldUsuario.getText().isEmpty()){
            TextFieldUsuario.setText("Ingrese el nombre de usuario");
            TextFieldUsuario.setForeground(Color.gray);
        }
        if(TextFieldContraseña.getText().isEmpty()){
            TextFieldContraseña.setText("Ingrese su contraseña");
            TextFieldContraseña.setForeground(Color.gray);
        }
        if(TextFielRContraseña.getText().isEmpty()){
            TextFielRContraseña.setText("Repita su contraseña");
            TextFielRContraseña.setForeground(Color.gray);
        }
        
    }//GEN-LAST:event_TextFieldCodigoPMousePressed

    private void BotonRegistrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseEntered
        // TODO add your handling code here:
        PBotonR.setBackground(new Color(64,238,255));
    }//GEN-LAST:event_BotonRegistrarMouseEntered

    private void BotonRegistrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseExited
        // TODO add your handling code here:
        PBotonR.setBackground(new Color(51,204,255));
    }//GEN-LAST:event_BotonRegistrarMouseExited

    private void BotonIniciarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonIniciarMouseEntered
        // TODO add your handling code here:
         PBotonIn.setBackground(new Color(64,238,255));
    }//GEN-LAST:event_BotonIniciarMouseEntered

    private void BotonIniciarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonIniciarMouseExited
        // TODO add your handling code here:
        PBotonIn.setBackground(new Color(51,204,255));
    }//GEN-LAST:event_BotonIniciarMouseExited
    public void setDatos(){
            Datos[0] = TextFieldUsuario.getText();
            Datos[1] = TextFieldContraseña.getText();
            Datos[2] = TextFieldNombre.getText();
            Datos[3] = TextFieldApellido.getText();
            Datos[4] = TextFieldCodigoP.getText();
            Datos[5] = (String) SexoComBox.getSelectedItem();
    }
    public String[] getDatos(){
        return this.Datos;
    }                                                         

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Back;
    public javax.swing.JLabel BotonIniciar;
    public javax.swing.JLabel BotonRegistrar;
    private javax.swing.JPanel Contenido;
    private javax.swing.JPanel Contenido2;
    private javax.swing.JPanel Decoracion;
    private javax.swing.JLabel LabelLogo;
    private javax.swing.JPanel PBotonIn;
    private javax.swing.JPanel PBotonR;
    private javax.swing.JSeparator Separador1;
    public javax.swing.JComboBox<String> SexoComBox;
    private javax.swing.JLabel Text1;
    private javax.swing.JLabel TextA;
    private javax.swing.JLabel TextC;
    private javax.swing.JLabel TextCBox;
    public javax.swing.JTextField TextFielRContraseña;
    public javax.swing.JTextField TextFieldApellido;
    public javax.swing.JTextField TextFieldCodigoP;
    public javax.swing.JTextField TextFieldContraseña;
    public javax.swing.JTextField TextFieldNombre;
    public javax.swing.JTextField TextFieldUsuario;
    private javax.swing.JLabel TextN;
    private javax.swing.JLabel TextNU;
    private javax.swing.JLabel TextRC;
    private javax.swing.JLabel TextS;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    // End of variables declaration//GEN-END:variables
}
